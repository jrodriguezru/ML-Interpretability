##### QUESTION BANK FOR AUTOGRADING QUESTIONS IN NOTEBOOK ######
# QUESTIONS is a dictionary that contains all the questions.
# Each entry contains all the information of a question.
# Each entry is a list composed by question as a String,
# Followed by a list with the options. And ending with the 
# correct answer as a String,

import ipywidgets as widgets
from IPython.display import display
from colorama import Fore

questions = {
    'shap_axioms': [
        "¿Cuál de los siguientes axiomas NO es uno de los axiomas de los valores SHAP?",
        ["Eficiencia", "Simetría", "Jugador nulo", "Invarianza"],
        "Invarianza"
    ],
    'wat_class_0': [
        "En la muestra 0, ¿de qué tipo es la contribución del feature 'car_power'?",
        ["Positiva", "Negativa"],
        "Positiva"
    ],
    'wat_class_1': [
        "En la muestra 0, ¿cuál es el feature que mayor contribución negativa tiene?",
        ["car_power", "car_age", "driver_age", "year", "car_weight", "town"],
        "car_age"
    ],
    'wat_class_2': [
        "En la muestra 0, ¿cuál feature tiene mayor contribución?",
        ["car_power", "car_age", "driver_age", "year", "car_weight", "town"],
        "car_power"
    ],
    'bar_class_0': [
        "¿Qué feature contribuye más en las predicciones de este modelo?",
        ["car_power", "car_age", "driver_age", "year", "car_weight", "town"],
        "car_power"
    ],
    'beeswarm_class_0': [
        "¿Qué feature tiene una distribución clara en contribuciones positivas y negativas de acuerdo a su valor?",
        ["car_power", "car_age", "driver_age", "year", "car_weight", "town"],
        "town"
    ],
    'beeswarm_class_1': [
        "Verdadero o Falso: El feature year tiene una contribución que depende de su valor.",
        ["Verdadero", "Falso"],
        "Falso"
    ],
    'explainer_choice': [
        "¿Qué explainer es más eficiente para modelos con menos de 15 features?",
        ["KernelExplainer", "DeepExplainer", "ExactExplainer", "TreeExplainer"],
        "ExactExplainer"
    ],
    'wat_reg_0': [
        "Verdadero o Falso: Para la muestra 0, todos los features tienen contribución positiva.",
        ["Verdadero", "Falso"],
        "Verdadero"
    ],
    'wat_reg_1': [
        "Para la muestra 0, ¿qué feature tiene la mayor contribución?",
        ["age", "bmi", "children", "smoker_yes", "sex_male", "region_northwest", "region_southwest", "region_southeast"],
        "age" 
    ],
    'bar_reg_0': [
        "Los dos features que más contribuyen a las predicciones de este modelo son:",
        ["region_southeast y age", "age y bmi", "sex_male y smoker_yes", "bmi y children"],
        "age y bmi"
    ],
    'bar_reg_1': [
        "Verdadero o Falso: Para este modelo, en general, todos los features tienen contribuciones negativas",
        ["Verdadero", "Falso"],
        "Falso"
    ],
    'beeswarm_reg_0': [
        "Verdadero o Falso: De acuerdo con el modelo, para una persona sin hijos, el seguro médico resultaría potencialmente más caro.",
        ["Verdadero", "Falso"],
        "Falso"
    ],
    'beeswarm_reg_1': [
        "Verdadero o Falso: De acuerdo con el modelo, las mujeres pagan potencialmente más por su seguro médico",
        ["Verdadero", "Falso"],
        "Falso"
    ]
    # Formato:
    # 'otra_pregunta': [
    #     "Texto de la pregunta",
    #     ["Opción A", "Opción B", "Opción C"],
    #     "Opción Correcta"
    # ]
}

def display_question(question_key: str):
    """
    Search for the question in questions, creates and shows the widgets.
    """
    if question_key not in questions:
        print(f"{Fore.RED}Error: La pregunta con la clave '{question_key}' no fue encontrada.{Fore.RESET}")
        return

    question_text, options, correct_answer = questions[question_key]

    # --- Widgets ---
    radio_buttons = widgets.RadioButtons(
        options=options,
        description=question_text,
        disabled=False,
        layout={'width': 'max-content'},
        style={'description_width': 'initial'}
    )

    button = widgets.Button(description="Verificar Respuesta")
    output = widgets.Output()

    # --- Lógica de Verificación (Función Anidada) ---
    def check_answer(b):
        """
        Esta función se ejecuta cuando se hace clic en el botón.
        Compara la respuesta seleccionada con la correcta.
        """
        with output:
            output.clear_output() # Limpia la salida anterior
            if radio_buttons.value == correct_answer:
                print(Fore.GREEN + "✅ ¡Correcto!" + Fore.RESET)
            else:
                print(f"{Fore.RED}❌ Incorrecto.{Fore.RESET}")

    # --- Conexión y Visualización ---
    button.on_click(check_answer) # Asigna la función check_answer al evento 'on_click' del botón
    
    # Muestra los widgets en el notebook
    display(radio_buttons, button, output)