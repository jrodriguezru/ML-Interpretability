import pytest
from PIL import Image
import numpy as np
from colorama import Fore



def compare_images(img1_path, img2_path, tolerance=10):
    """Compares two images and returns True if they are similar, False otherwise."""
    try:
        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')
    except FileNotFoundError as e:
        print(f"Error opening image file: {e}")
        return False

    if img1.size != img2.size:
        # Optional: Resize for comparison if needed, but for this case, sizes should match
        # img2 = img2.resize(img1.size)
        print("Plot sizes do not match.")
        return False

    img1_data = np.array(img1)
    img2_data = np.array(img2)

    diff = np.sum(np.abs(img1_data - img2_data))
    
    # Normalize the difference by the number of pixels and channels
    num_pixels = img1.size[0] * img1.size[1] * 3
    normalized_diff = diff / num_pixels
    
    return normalized_diff <= tolerance


# Pytest tests

def test_plot(plot_to_test: str):
    if plot_to_test == "wat1":
        assert compare_images('reference_images/Waterfall1.png', 'generated_images/waterfall_1.png')
    elif plot_to_test == "bar1":
        assert compare_images('reference_images/Bar1.png', 'generated_images/bar_1.png')
    elif plot_to_test == "beesworm1":
        assert compare_images('reference_images/Beeswarm1.png', 'generated_images/beeswarm_1.png')
    elif plot_to_test == "wat2":
        assert compare_images('reference_images/Waterfall2.png', 'generated_images/waterfall_2.png')
    elif plot_to_test == "bar2":
        assert compare_images('reference_images/Bar2.png', 'generated_images/bar_2.png')
    elif plot_to_test == "beesowrm2":
        assert compare_images('reference_images/Beeswarm2.png', 'generated_images/beeswarm_2.png')


def test_waterfall_plot_classification():
    try:
        test_plot("wat1")
        print(Fore.GREEN + "Waterfall plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Waterfall plot test failed. ❌" + Fore.RESET)

def test_bar_plot_classification():
    try:
        test_plot("bar1")
        print(Fore.GREEN + "Bar plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Bar plot test failed. ❌" + Fore.RESET)
        
def test_beeswarm_plot_classification():
    try:
        test_plot("beesworm1")
        print(Fore.GREEN + "Beeswarm plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Beeswarm plot test failed. ❌" + Fore.RESET)

def test_waterfall_plot_regression():
    try:
        test_plot("wat2")
        print(Fore.GREEN + "Waterfall plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Waterfall plot test failed. ❌" + Fore.RESET)

def test_bar_plot_regression():
    try:
        test_plot("bar2")
        print(Fore.GREEN + "Bar plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Bar plot test failed. ❌" + Fore.RESET)

def test_beeswarm_plot_regression():
    try:
        test_plot("beesworm2")
        print(Fore.GREEN + "Beeswarm plot test passed! ✅" + Fore.RESET)
    except AssertionError:
        print(Fore.RED + "Beeswarm plot test failed. ❌" + Fore.RESET)
